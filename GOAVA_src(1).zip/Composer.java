import java.util.Vector;

public class Composer {
	public Float getNote(float num, Integer step,Vector<Float> numbers) {
		float sum=0.0f;
		//return frequency index
		for(int i=0;i<numbers.size();i++) {
			if(numbers.get(i)!=0) {
				sum += (float)(1.0f+Math.cos(1.0f+Math.abs((3.14159f/2.0f)*num)+(3.14159f/2.0f)*((float)(((Math.abs(numbers.get(i))+Math.abs(num)))*step))))/(numbers.size()+Math.abs(num-numbers.get(i)));

			}else {
			sum += (float)(1.0f+Math.cos(1.0f+step+Math.abs((3.14159f/2.0f)*num)+(3.14159f/2.0f)*((float)(((Math.abs(numbers.get(i))+Math.abs(num)))*step))))/(numbers.size()+Math.abs(num-numbers.get(i)));
			}
		}
		sum = Math.abs(sum);
		
		return (float)sum;
	}
}
